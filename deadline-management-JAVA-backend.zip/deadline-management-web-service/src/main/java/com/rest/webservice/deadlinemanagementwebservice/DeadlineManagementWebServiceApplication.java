package com.rest.webservice.deadlinemanagementwebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeadlineManagementWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeadlineManagementWebServiceApplication.class, args);
	}

}
