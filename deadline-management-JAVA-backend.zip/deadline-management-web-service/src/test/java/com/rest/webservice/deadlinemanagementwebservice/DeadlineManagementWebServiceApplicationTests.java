package com.rest.webservice.deadlinemanagementwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeadlineManagementWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
